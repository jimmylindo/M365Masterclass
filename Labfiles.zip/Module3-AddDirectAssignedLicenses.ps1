﻿#Module3-AddDirectAssignedLicenses.ps1
#Connect to Azure AD
Connect-MsolService

#Get Office 365 E5 SKU ID
$skuidO365=Get-MsolAccountSku | Where-Object {$_.AccountSkuId -like '*ENTERPRISEPREMIUM*'}
$skuidO365 = $skuidO365.AccountSkuID

$skuidEMS=Get-MsolAccountSku | Where-Object {$_.AccountSkuId -like '*EMSPREMIUM*'}
$skuidEMS = $skuidEMS.AccountSkuID

#Get all group members
$group=Get-MsolGroup | Where-Object {$_.DisplayName -eq 'Licenses'}
$user=Get-MsolGroupMember -GroupObjectId $group.ObjectId

#Add direct assigned license to users
foreach ($u in $user) {
    Set-MsolUser -UserPrincipalName $u.EmailAddress -UsageLocation "SE"
    Set-MsolUserLicense -UserPrincipalName $u.EmailAddress -AddLicenses $skuidO365
    Set-MsolUserLicense -UserPrincipalName $u.EmailAddress -AddLicenses $skuidEMS
    Write-Output $u.UserPrincipalName
    } 
