﻿$ObjectID = 'c608b624-6ec7-4733-9f8e-9769faa66f56'

$template = Get-MsolAllSettingTemplate | where-object {$_.displayname -eq "Group.Unified"}
$setting = $template.CreateSettingsObject()
$setting["EnableGroupCreation"] = "false"
$setting["GroupCreationAllowedGroupId"] = $ObjectID
New-MsolSettings -SettingsObject $setting
