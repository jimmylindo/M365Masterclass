﻿"Office 365 E5" | ForEach-Object -Process {
     New-ADGroup -Path "OU=Groups,OU=ACME,DC=corp,DC=acme,DC=com" -GroupCategory Security -GroupScope Global `
                 -Name $_ -Description "Assigns licenses for $_"
}
"EMS E5" | ForEach-Object -Process {
     New-ADGroup -Path "OU=Groups,OU=ACME,DC=corp,DC=acme,DC=com" -GroupCategory Security -GroupScope Global `
                 -Name $_ -Description "Assigns licenses for $_"
}

$members = Get-ADUser -SearchBase "OU=Users,OU=ACME,DC=corp,DC=acme,DC=com" -Filter {enabled -eq $true} 
Add-ADGroupMember -Identity "Office 365 E5" -Members ($members | Select-Object -First 10)
Add-ADGroupMember -Identity "EMS E5" -Members ($members | Select-Object -First 10)

