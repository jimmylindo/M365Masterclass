﻿$Cred = Get-Credential
Connect-AzureAD -Credential $Cred

$domain = get-adforest |select upnsuffixes -ExpandProperty upnsuffixes

New-AzureADDomain -Name $domain -IsDefault $true

