﻿#Connect to Exchange Online With PowerShell
C:\Labfiles\Module0-Connect-JDO365Services.ps1 -Services EXO
#Enable ADAL/Modern authentication support
Set-OrganizationConfig -OAuth2ClientProfileEnabled:$true -Verbose
#Verify enablement
Get-OrganizationConfig | Select-Object name, *OAuth*