﻿$DomainName = "lab34241.o365ready.com"
Get-ADForest | Set-ADForest -UPNSuffixes @{Add=$DomainName}

