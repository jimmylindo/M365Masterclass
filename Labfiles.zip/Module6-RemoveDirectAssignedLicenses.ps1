﻿
#Connect to Azure AD
Connect-MsolService

#Get Office 365 E5 SKU ID
$skuid=Get-MsolAccountSku | Where-Object {$_.AccountSkuId -like '*ENTERPRISEPREMIUM*'}
$skuId = $skuid.AccountSkuID

#Get all group members
$group=Get-MsolGroup | Where-Object {$_.DisplayName -eq 'Office 365 E5'}
$user=Get-MsolGroupMember -GroupObjectId $group.ObjectId | where islicensed -EQ $true | fl

#Remove direct assigned license from users
foreach ($u in $user) {
    Set-MsolUserLicense -UserPrincipalName $u.EmailAddress -RemoveLicenses $skuid
    Write-Output $u.UserPrincipalName
    } 
