﻿
#Connect to Azure AD
Connect-MsolService

#Get Office 365 E5 SKU ID
$skuid=Get-MsolAccountSku | Where-Object {$_.AccountSkuId -like '*ENTERPRISEPREMIUM*'}
$skuId = $skuid.AccountSkuID

#Get Office 365 EMS SKU ID
$skuid2 = Get-MsolAccountSku | Where-Object {$_.AccountSkuId -like '*EMSPREMIUM*'}
$skuId2 = $skuid.AccountSkuID

#Get all group members
$group=Get-MsolGroup | Where-Object {$_.DisplayName -eq 'Licenses'}
$user=Get-MsolGroupMember -GroupObjectId $group.ObjectId | where islicensed -EQ $true

#Remove direct assigned license from users
foreach ($u in $user) {
    Set-MsolUserLicense -UserPrincipalName $u.EmailAddress -RemoveLicenses $skuid
    Set-MsolUserLicense -UserPrincipalName $u.EmailAddress -RemoveLicenses $skuid2
    Write-Output $u.UserPrincipalName
    } 
