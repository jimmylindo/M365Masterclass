﻿$templatePath = "C:\VMs\Templates\W10REF.vhdx"
$VMFolderPath = "C:\VMs"
$vSwitch = "InternalNATSwitch"
$maxRAM = 2GB
$diffName = "Differencing Disk Initial Deployment"
$VMName = "WindowsAutopilot"

#Set the parent VHDX as Read-Only
Set-ItemProperty -Path $templatePath -Name IsReadOnly -Value $true

#Create a folder for the new VM, check if exists.
    If (Test-Path ($VMFolderPath + "\" + $VMName)){
     Write-host "FOLDER ALREADY EXISTS. EXITING."
     exit
     }
    If ((Test-Path $templatePath) -eq $false){
     Write-host "COULDN'T FIND YOUR TEMPLATE. EXITING."
     exit
     }
$path = new-item $VMFolderPath\$VMName -ItemType Directory

#Create the Differencing Disk VHD
$VHD = New-VHD -Path ($path.FullName + "\" + $vmname + ".vhdx") -ParentPath $templatePath -Differencing

#Create the Virtual Machine; point to the Differential VHD
new-vm -Name $VMName -Path $VMFolderPath -VHDPath $VHD.Path -BootDevice VHD -Generation 2 -SwitchName $vSwitch | `
 Set-VMMemory -DynamicMemoryEnabled $true `
 -MaximumBytes $maxRAM -MinimumBytes 512MB -StartupBytes 2GB `

Start-vm $VMName
