$Cred = Get-Credential
Connect-AzureAD -Credential $Cred

$domain = get-adforest |select upnsuffixes -ExpandProperty upnsuffixes

Get-AzureADDomainVerificationDnsRecord -Name $domain | Where-Object {$_.RecordType -eq 'txt'} | fl