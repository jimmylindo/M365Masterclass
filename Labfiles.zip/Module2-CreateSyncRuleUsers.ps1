﻿$newpwd = ConvertTo-SecureString -String "P@ssw0rd" -AsPlainText –Force

New-ADUser -DisplayName:"Michael Schott" -GivenName:"Michael" -Name:"Michael Schott" -Path:"OU=Users,OU=ACME,DC=corp,DC=acme,DC=com" -SamAccountName:"micsch" -Server:"acme-dc01.corp.acme.com" -Surname:"Schott" -Type:"user" -UserPrincipalName:"micsch@corp.acme.com" -Description "Test sync rule"
Set-ADAccountPassword -Identity:"CN=Michael Schott,OU=Users,OU=ACME,DC=corp,DC=acme,DC=com" -NewPassword:$newpwd -Reset:$true -Server:"acme-dc01.corp.acme.com"
Enable-ADAccount -Identity:"CN=Michael Schott,OU=Users,OU=ACME,DC=corp,DC=acme,DC=com" -Server:"acme-dc01.corp.acme.com"