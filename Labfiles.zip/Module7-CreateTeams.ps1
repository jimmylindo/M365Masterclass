Param(
    [string]$department, #Description of department example HR,RND
    [string]$teamname, #Name of the team
    [string]$description, #Please describe the use of this team in short text 
    [string]$teamowner #The email address of the owner of the Team
)

#Connect to Teams PowerShell
$cred = Get-AutomationPSCredential -Name "AzureAD Admin"
$teams = Connect-MicrosoftTeams -Credential $cred

#Generate TeamsName Function
function New-JLTeamName {
    param (
        [Parameter(Mandatory=$true)][string]$department,
        [Parameter(Mandatory=$true)][string]$teamname
    )
    #Construct the base TeamName
    $BaseName = "{0}{1}{2}" -f ($department),"-",($teamname)
  
    #Add a number until you find a free sAMAccountName
    if (Get-Team -ErrorAction SilentlyContinue |where displayname -Like $BaseName) {
        $index = 0
        do {
            $index++
            $FinalTeamName = "{0}{1}" -f $BaseName.Toupper(),$index
        } until (!(Get-Team -ErrorAction SilentlyContinue |where displayname -Like $FinalTeamName))
    } else {
        $FinalTeamName = $BaseName.toupper()
    }
    return $FinalTeamName
}

$FinalTeamName = New-JLTeamName -department $department -teamname $teamname

$Alias = $FinalTeamName -replace '\s',''

#Create the Team
$newteam = New-Team -MailNickName $Alias -DisplayName $FinalTeamName -Description $description -Owner $teamowner -Visibility Private 


#Return to Flow the new teams GroupID by passing the object as JSON
write-output $newteam | convertto-json

#Hangup
Disconnect-MicrosoftTeams