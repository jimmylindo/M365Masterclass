﻿configuration CreateHyperV
{
   param
   (
        [string]$NodeName = 'localhost'
    )

    Import-DscResource -ModuleName xHyper-V, PSDesiredStateConfiguration, xPendingReboot

    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature 'Hyper-V' {
            Ensure='Present'
            Name='Hyper-V'
       }

       xPendingReboot RebootAfterPromotion{
        Name = "RebootAfterPromotion"
        DependsOn = "[WindowsFeature]Hyper-V"
    }

       WindowsFeature 'Hyper-V-Powershell' {
            Ensure='Present'
            Name='Hyper-V-Powershell'
       }

       File VMsTemplate
       {
            Ensure = 'Present'
            Type = 'Directory'
            DestinationPath = "$($env:SystemDrive)\VMs\templates"
       }
       File VMsScripts
       {
            Ensure = 'Present'
            Type = 'Directory'
            DestinationPath = "$($env:SystemDrive)\VMs\Scripts"
       }

   }
}